﻿using PiñateriaMandM.DataAccess;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PiñateriaMandM.BusinessLogic
{
    public class PurchaseDetailBL
    {
        private static PurchaseDetailBL _instance;
        public static PurchaseDetailBL Instance
        {
            get
            {
                return _instance ?? (_instance = new PurchaseDetailBL());
            }
        }

        public bool Insert(PurchaseDetail entity)
        {
            bool result = false;
            try
            {
                result = PurchaseDetailDAL.Instance.Insert(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Update(PurchaseDetail entity)
        {
            bool result = false;
            try
            {
                result = PurchaseDetailDAL.Instance.Update(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;
            try
            {
                result = PurchaseDetailDAL.Instance.Delete(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public List<PurchaseDetail> SelectAll()
        {
            List<PurchaseDetail> result = null;
            try
            {
                result = PurchaseDetailDAL.Instance.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public PurchaseDetail SelectById(int id)
        {
            PurchaseDetail result = null;
            try
            {
                result = PurchaseDetailDAL.Instance.SelectById(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }
    }

}
