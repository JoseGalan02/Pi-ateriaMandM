﻿using PiñateriaMandM.DataAccess;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PiñateriaMandM.BusinessLogic
{
    public class EmployeeBL
    {
        private static EmployeeBL _instance;
        public static EmployeeBL Instance
        {
            get
            {
                return _instance ?? (_instance = new EmployeeBL());
            }
        }

        public bool Insert(Employee entity)
        {
            bool result = false;
            try
            {
                result = EmployeeDAL.Instance.Insert(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Update(Employee entity)
        {
            bool result = false;
            try
            {
                result = EmployeeDAL.Instance.Update(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;
            try
            {
                result = EmployeeDAL.Instance.Delete(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public List<Employee> SelectAll()
        {
            List<Employee> result = null;
            try
            {
                result = EmployeeDAL.Instance.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public Employee SelectById(int id)
        {
            Employee result = null;
            try
            {
                result = EmployeeDAL.Instance.SelectById(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }
    }

}
