﻿using PiñateriaMandM.DataAccess;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PiñateriaMandM.BusinessLogic
{
    public class UserBL
    {
        private static UserBL _instance;
        public static UserBL Instance
        {
            get
            {
                return _instance ?? (_instance = new UserBL());
            }
        }

        public bool Insert(User entity)
        {
            bool result = false;
            try
            {
                result = UserDAL.Instance.Insert(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Update(User entity)
        {
            bool result = false;
            try
            {
                result = UserDAL.Instance.Update(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;
            try
            {
                result = UserDAL.Instance.Delete(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public List<User> SelectAll()
        {
            List<User> result = null;
            try
            {
                result = UserDAL.Instance.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public User SelectById(int id)
        {
            User result = null;
            try
            {
                result = UserDAL.Instance.SelectById(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }
    }

}
