﻿using PiñateriaMandM.DataAccess;
using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PiñateriaMandM.BusinessLogic
{
    public class PromotionBL
    {
        private static PromotionBL _instance;
        public static PromotionBL Instance
        {
            get
            {
                return _instance ?? (_instance = new PromotionBL());
            }
        }

        public bool Insert(Promotion entity)
        {
            bool result = false;
            try
            {
                result = PromotionDAL.Instance.Insert(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Update(Promotion entity)
        {
            bool result = false;
            try
            {
                result = PromotionDAL.Instance.Update(entity);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;
            try
            {
                result = PromotionDAL.Instance.Delete(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public List<Promotion> SelectAll()
        {
            List<Promotion> result = null;
            try
            {
                result = PromotionDAL.Instance.SelectAll();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }

        public Promotion SelectById(int id)
        {
            Promotion result = null;
            try
            {
                result = PromotionDAL.Instance.SelectById(id);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return result;
        }
    }

}
