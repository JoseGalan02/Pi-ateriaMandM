﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PiñateriaMandM.Entity
{
    public class PurchaseDetail
    {
        public int PurchaseDetailId { get; set; }

        // Llave foránea
        public int PurchaseId { get; set; }
      

        // Llave foránea
        public int ProductsId { get; set; }
      

        public int Quantity { get; set; }
        public decimal PricePerUnit { get; set; }
    }

}
