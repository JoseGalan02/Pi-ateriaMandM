﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PiñateriaMandM.Entity;


namespace PiñateriaMandM.DataAccess
{
    public class SaleDAL:Connection
    {
        private static SaleDAL _instance;
        public static SaleDAL Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new SaleDAL();
                return _instance;
            }
        }

        public bool Insert(Sale entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spInsertSale", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SaleDate", entity.SaleDate);
                    cmd.Parameters.AddWithValue("@TotalAmount", entity.TotalAmount);
                    cmd.Parameters.AddWithValue("@CustomerId", entity.CustomerId);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Update(Sale entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spUpdateSale", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SaleId", entity.SaleId);
                    cmd.Parameters.AddWithValue("@SaleDate", entity.SaleDate);
                    cmd.Parameters.AddWithValue("@TotalAmount", entity.TotalAmount);
                    cmd.Parameters.AddWithValue("@CustomerId", entity.CustomerId);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spDeleteSale", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SaleId", id);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public List<Sale> SelectAll()
        {
            List<Sale> result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spSaleSelectAll", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            result = new List<Sale>();

                            while (dr.Read())
                            {
                                Sale entity = new Sale()
                                {
                                    SaleId = dr.GetInt32(0),
                                    SaleDate = dr.GetString(1),
                                    TotalAmount = dr.GetDecimal(2),
                                    CustomerId = dr.GetInt32(3)
                                };

                                result.Add(entity);
                            }
                        }
                    }
                }
            }

            return result;
        }

        public Sale SelectById(int id)
        {
            Sale result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spSaleSelectById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SaleId", id);

                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            while (dr.Read())
                            {
                                result = new Sale()
                                {
                                    SaleId = dr.GetInt32(0),
                                    SaleDate = dr.GetString(1),
                                    TotalAmount = dr.GetDecimal(2),
                                    CustomerId = dr.GetInt32(3)
                                };
                            }
                        }
                    }
                }
            }

            return result;
        }
    }
}
