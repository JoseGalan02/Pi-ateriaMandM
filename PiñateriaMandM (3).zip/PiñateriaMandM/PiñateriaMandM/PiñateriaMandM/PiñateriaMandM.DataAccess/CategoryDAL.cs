﻿using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace PiñateriaMandM.DataAccess
{
    public class CategoryDAL : Connection
    {
        private static CategoryDAL _instance;
        public static CategoryDAL Instance

        {

            get
            {
                if (_instance == null)
                    _instance = new CategoryDAL();
                return _instance;


            }
        }
        public bool Insert(Category entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))

            {

                using (SqlCommand cmd = new SqlCommand("spCategoriaInsert", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Name", entity.Name);
                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;


                }


            }
            return result;
        }

        public bool Update(Category entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spCategoryUpdate", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@CategoryId", entity.CategoryId);
                    cmd.Parameters.AddWithValue("@Name", entity.Name);
                    cmd.Parameters.AddWithValue("@Description", entity.Description); // Si es necesario

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spCategoryDelete", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@CategoryId", id);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public List<Category> SelectAll()
        {
            List<Category> result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spCategorySelectAll", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            result = new List<Category>();

                            while (dr.Read())
                            {
                                Category entity = new Category()
                                {
                                    CategoryId = dr.GetInt32(0),
                                    Name = dr.GetString(1),
                                    Description = dr.IsDBNull(2) ? null : dr.GetString(2) // Manejo de posibles valores nulos
                                };

                                result.Add(entity);
                            }
                        }
                    }
                }
            }

            return result;
        }

        public Category SelectById(int id)
        {
            Category result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spCategorySelectById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@CategoryId", id);

                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            while (dr.Read())
                            {
                                result = new Category()
                                {
                                    CategoryId = dr.GetInt32(0),
                                    Name = dr.GetString(1),
                                    Description = dr.IsDBNull(2) ? null : dr.GetString(2) // Manejo de posibles valores nulos
                                };
                            }
                        }
                    }
                }
            }

            return result;
        }



    }
}
