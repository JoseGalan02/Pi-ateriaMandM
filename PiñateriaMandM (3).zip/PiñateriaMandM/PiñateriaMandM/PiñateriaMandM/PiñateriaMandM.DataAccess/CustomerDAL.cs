﻿using PiñateriaMandM.Entity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PiñateriaMandM.DataAccess
{
    public class CustomerDAL: Connection
    {


        private static CustomerDAL _instance;
        public static CustomerDAL Instance

        {

            get
            {
                if (_instance == null)
                    _instance = new CustomerDAL();
                return _instance;


            }
        }


        public bool Insert(Customer entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spCustomerInsert", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Name", entity.Name);
                    cmd.Parameters.AddWithValue("@Address", entity.Address);
                    cmd.Parameters.AddWithValue("@Phone", entity.Phone);
                    cmd.Parameters.AddWithValue("@DeliveryAddress", entity.DeliveryAddress);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Update(Customer entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spCustomerUpdate", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@CustomerId", entity.CustomerId);
                    cmd.Parameters.AddWithValue("@Name", entity.Name);
                    cmd.Parameters.AddWithValue("@Address", entity.Address);
                    cmd.Parameters.AddWithValue("@Phone", entity.Phone);
                    cmd.Parameters.AddWithValue("@DeliveryAddress", entity.DeliveryAddress);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spCustomerDelete", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@CustomerId", id);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public Customer SelectById(int id)
        {
            Customer result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spCustomerSelectById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@CustomerId", id);

                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            while (dr.Read())
                            {
                                result = new Customer()
                                {
                                    CustomerId = dr.GetInt32(0),
                                    Name = dr.GetString(1),
                                    Address = dr.IsDBNull(2) ? null : dr.GetString(2),
                                    Phone = dr.IsDBNull(3) ? null : dr.GetString(3),
                                    DeliveryAddress = dr.IsDBNull(4) ? null : dr.GetString(4)
                                };
                            }
                        }
                    }
                }
            }

            return result;
        }

        public List<Customer> SelectAll()
        {
            List<Customer> result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spCustomerSelectAll", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            result = new List<Customer>();

                            while (dr.Read())
                            {
                                Customer entity = new Customer()
                                {
                                    CustomerId = dr.GetInt32(0),
                                    Name = dr.GetString(1),
                                    Address = dr.IsDBNull(2) ? null : dr.GetString(2),
                                    Phone = dr.IsDBNull(3) ? null : dr.GetString(3),
                                    DeliveryAddress = dr.IsDBNull(4) ? null : dr.GetString(4)
                                };

                                result.Add(entity);
                            }
                        }
                    }
                }
            }

            return result;
        }







    }
}
