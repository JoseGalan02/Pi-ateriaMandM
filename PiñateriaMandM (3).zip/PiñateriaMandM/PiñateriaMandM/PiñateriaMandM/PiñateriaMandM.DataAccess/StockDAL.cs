﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PiñateriaMandM.Entity;


namespace PiñateriaMandM.DataAccess
{
    public class StockDAL:Connection
    {
        private static StockDAL _instance;
        public static StockDAL Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new StockDAL();
                return _instance;
            }
        }

        public bool Insert(Stock entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spInsertStock", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ProductId", entity.ProductId);
                    cmd.Parameters.AddWithValue("@Quantity", entity.Quantity);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Update(Stock entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spUpdateStock", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@StockId", entity.StockId);
                    cmd.Parameters.AddWithValue("@ProductId", entity.ProductId);
                    cmd.Parameters.AddWithValue("@Quantity", entity.Quantity);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spDeleteStock", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@StockId", id);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public List<Stock> SelectAll()
        {
            List<Stock> result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spStockSelectAll", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            result = new List<Stock>();

                            while (dr.Read())
                            {
                                Stock entity = new Stock()
                                {
                                    StockId = dr.GetInt32(0),
                                    ProductId = dr.GetInt32(1),
                                    Quantity = dr.GetInt32(2)
                                };

                                result.Add(entity);
                            }
                        }
                    }
                }
            }

            return result;
        }

        public Stock SelectById(int id)
        {
            Stock result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spStockSelectById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@StockId", id);

                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            while (dr.Read())
                            {
                                result = new Stock()
                                {
                                    StockId = dr.GetInt32(0),
                                    ProductId = dr.GetInt32(1),
                                    Quantity = dr.GetInt32(2)
                                };
                            }
                        }
                    }
                }
            }

            return result;
        }
    }
}