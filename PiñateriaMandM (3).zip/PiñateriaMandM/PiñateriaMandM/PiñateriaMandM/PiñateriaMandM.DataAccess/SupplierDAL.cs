﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PiñateriaMandM.Entity;

namespace PiñateriaMandM.DataAccess
{
    public class SupplierDAL:Connection
    {
        public static SupplierDAL _instance;
        public static SupplierDAL Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new SupplierDAL();
                return _instance;
            }
        }

        public bool Insert(Supplier entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spInsertSupplier", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Name", entity.Name);
                    cmd.Parameters.AddWithValue("@Phone", entity.Phone);
                    cmd.Parameters.AddWithValue("@Email", entity.Email);
                    cmd.Parameters.AddWithValue("@Address", entity.Address);
                    cmd.Parameters.AddWithValue("@ContactPerson", entity.ContactPerson);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Update(Supplier entity)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spUpdateSupplier", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SupplierId", entity.SupplierId);
                    cmd.Parameters.AddWithValue("@Name", entity.Name);
                    cmd.Parameters.AddWithValue("@Phone", entity.Phone);
                    cmd.Parameters.AddWithValue("@Email", entity.Email);
                    cmd.Parameters.AddWithValue("@Address", entity.Address);
                    cmd.Parameters.AddWithValue("@ContactPerson", entity.ContactPerson);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public bool Delete(int id)
        {
            bool result = false;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spDeleteSupplier", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SupplierId", id);

                    conn.Open();
                    result = cmd.ExecuteNonQuery() > 0;
                }
            }

            return result;
        }

        public List<Supplier> SelectAll()
        {
            List<Supplier> result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spSupplierSelectAll", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            result = new List<Supplier>();

                            while (dr.Read())
                            {
                                Supplier entity = new Supplier()
                                {
                                    SupplierId = dr.GetInt32(0),
                                    Name = dr.GetString(1),
                                    Phone = dr.IsDBNull(2) ? null : dr.GetString(2),
                                    Email = dr.IsDBNull(3) ? null : dr.GetString(3),
                                    Address = dr.IsDBNull(4) ? null : dr.GetString(4),
                                    ContactPerson = dr.IsDBNull(5) ? null : dr.GetString(5)
                                };

                                result.Add(entity);
                            }
                        }
                    }
                }
            }

            return result;
        }

        public Supplier SelectById(int id)
        {
            Supplier result = null;

            using (SqlConnection conn = new SqlConnection(_cadena))
            {
                using (SqlCommand cmd = new SqlCommand("spSupplierSelectById", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SupplierId", id);

                    conn.Open();
                    using (SqlDataReader dr = cmd.ExecuteReader(CommandBehavior.SingleResult))
                    {
                        if (dr != null)
                        {
                            while (dr.Read())
                            {
                                result = new Supplier()
                                {
                                    SupplierId = dr.GetInt32(0),
                                    Name = dr.GetString(1),
                                    Phone = dr.IsDBNull(2) ? null : dr.GetString(2),
                                    Email = dr.IsDBNull(3) ? null : dr.GetString(3),
                                    Address = dr.IsDBNull(4) ? null : dr.GetString(4),
                                    ContactPerson = dr.IsDBNull(5) ? null : dr.GetString(5)
                                };
                            }
                        }
                    }
                }
            }

            return result;
        }
    }
}
